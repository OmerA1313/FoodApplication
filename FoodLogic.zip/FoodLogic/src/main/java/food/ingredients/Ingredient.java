package food.ingredients;

public class Ingredient {
    private String id;
    private String aisle;
    private String image;
    private String name;
    private float amount;
    private String unit;

}
