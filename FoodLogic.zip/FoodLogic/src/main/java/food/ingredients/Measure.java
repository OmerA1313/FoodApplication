package food.ingredients;

public class Measure {
//    public enum eMeasureUnit{
//        teaspoon,teaspoons, tablespoon, tabelspoons, cup, cups, milliliters, liters, can, cans, small, clove, cloves,
//    }

    private float m_Amount;
    private String m_Unit;
}
