package food.recipes;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;

import food.ingredients.Ingredient;
import food.ingredients.IngredientInRecipe;

public class Recipe {
    private String title;
    private String id;
    private int readyInMinutes;
    private int servings;
    private Ingredient[] extendedIngredients;
    private List<IngredientInRecipe> missedIngredients;
    private String image;
    private String sourceUrl;
    private String instructions;

    public String getTitle() {
        return title;
    }

    public String getId() {
        return id;
    }

    public int getReadyInMinutes() {
        return readyInMinutes;
    }

    public int getServings() {
        return servings;
    }

    public Ingredient[] getExtendedIngredients() {
        return extendedIngredients;
    }

    public List<IngredientInRecipe> getMissedIngredients() {
        return missedIngredients;
    }

    public String getImage() {
        return image;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public String getInstructions() {
        return instructions;
    }
}